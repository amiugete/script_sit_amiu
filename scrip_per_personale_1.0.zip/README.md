Installazione 

Installare python sul proprio PC https://www.python.org/downloads/
