cartella per file output
