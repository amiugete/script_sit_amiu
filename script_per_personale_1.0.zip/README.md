### Archivio

git archive --format=zip HEAD:personale/ > scrip_per_personale_1.0.zip

### Installazione

Installare python sul proprio PC https://www.python.org/downloads/
