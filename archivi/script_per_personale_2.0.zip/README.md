### Archivio

git archive --format=zip HEAD:personale/ > script_per_personale_1.0.zip

### Installazione

Installare python sul proprio PC https://www.python.org/downloads/
