cartella per file input
