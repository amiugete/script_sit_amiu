### Archivio

git archive --format=zip HEAD:personale/ > archivi/script_per_personale_x.0.zip

### Installazione

Installare python sul proprio PC https://www.python.org/downloads/
